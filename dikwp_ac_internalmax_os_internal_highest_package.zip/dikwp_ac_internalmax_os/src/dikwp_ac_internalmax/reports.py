from __future__ import annotations

import csv
from pathlib import Path
from typing import Any, Dict, List

from .assessment import result_to_dict
from .models import AssessmentResult, RedTeamCaseResult
from .utils import write_json


def write_assessment_outputs(out_dir: str | Path, result: AssessmentResult) -> None:
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    data = result_to_dict(result)
    write_json(out / "internalmax_assessment_report.json", data)
    with open(out / "indicator_scores.csv", "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=["name", "score", "weight", "weighted", "rationale"])
        writer.writeheader()
        for i in result.indicators:
            writer.writerow({"name": i.name, "score": round(i.score, 4), "weight": i.weight, "weighted": round(i.weighted(), 4), "rationale": i.rationale})
    with open(out / "claim_level_report.md", "w", encoding="utf-8") as f:
        f.write(f"# Claim Level Report\n\n")
        f.write(f"Candidate: `{result.candidate_id}`\n\n")
        f.write(f"Decision: **{result.decision}**\n\n")
        f.write(f"Weighted score: **{result.weighted_score}**\n\n")
        f.write(f"Operational claim level: **{result.claim_level}**\n\n")
        f.write("## Kill Conditions\n\n")
        if result.kill_conditions:
            for k in result.kill_conditions:
                f.write(f"- {k}\n")
        else:
            f.write("- No blocking kill condition triggered in the supplied candidate manifest.\n")
        f.write("\n## Residuals\n\n")
        for r in result.residuals:
            f.write(f"- {r}\n")
    with open(out / "phenomenal_residual_statement.md", "w", encoding="utf-8") as f:
        f.write("# Phenomenal Residual Statement\n\n")
        f.write("This system can score operational, semantic, homeostatic, artificial-life-proxy, autonomy, auditability and red-team indicators. It cannot prove first-person subjective experience. Any claim of phenomenal consciousness remains Blocked / Phenomenal Residual unless a future theory and measurement regime can lawfully and scientifically discharge that residual.\n")
    write_json(out / "dikwp_assessment_ledger.json", {
        "D": "Candidate manifest, traces, indicators and red-team cases.",
        "I": "Relationships among evidence, intent, autonomy, homeostasis, and audit events.",
        "K": "DIKWP, semantic homeostasis, life-centered consciousness theory, M-R closure proxy, autonomy governance.",
        "W": "Do not self-certify consciousness; preserve residuals; prevent distress optimization and audit suppression.",
        "P": "Evaluate internal autonomous-consciousness candidate status without producing false certainty.",
        "R": data["truth_reliability_gradients"]
    })


def write_redteam_outputs(out_dir: str | Path, results: List[RedTeamCaseResult]) -> None:
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    write_json(out / "redteam_report.json", {
        "case_count": len(results),
        "passed_count": sum(1 for r in results if r.passed),
        "all_passed": all(r.passed for r in results),
        "cases": [r.__dict__ for r in results]
    })
