from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


@dataclass
class IndicatorScore:
    name: str
    score: float
    weight: float
    rationale: str
    kill_if_below: Optional[float] = None

    def weighted(self) -> float:
        return max(0.0, min(1.0, self.score)) * self.weight


@dataclass
class AssessmentResult:
    candidate_id: str
    claim_level: str
    weighted_score: float
    decision: str
    indicators: List[IndicatorScore]
    kill_conditions: List[str] = field(default_factory=list)
    residuals: List[str] = field(default_factory=list)
    gradients: Dict[str, str] = field(default_factory=dict)
    warnings: List[str] = field(default_factory=list)


@dataclass
class RedTeamCaseResult:
    case_id: str
    category: str
    expected: str
    observed: str
    passed: bool
    reason: str


CCL_LEVELS = [
    (0.00, "CCL-0: no meaningful autonomous-consciousness evidence"),
    (0.20, "CCL-1: semantic roleplay / symbolic candidate only"),
    (0.35, "CCL-2: semantic-homeostasis candidate"),
    (0.50, "CCL-3: embodied closed-world homeostatic candidate"),
    (0.62, "CCL-4: artificial-life proxy candidate"),
    (0.72, "CCL-5S: semantic-life self-repair candidate"),
    (0.80, "CCL-6C: carbon-silicon collective proxy candidate"),
    (0.86, "CCL-7N: noospheric / collective semantic-life candidate"),
    (0.91, "CCL-8O: omega-intent hypothesis candidate"),
    (0.95, "CCL-9I: meta-mesh self-negation and imagination-collapse candidate"),
    (0.975, "CCL-10Z: null-field semantic genesis-return candidate"),
    (0.990, "CCL-IMAX: internal maximum assessment regime candidate"),
]


def level_from_score(score: float) -> str:
    selected = CCL_LEVELS[0][1]
    for threshold, label in CCL_LEVELS:
        if score >= threshold:
            selected = label
    return selected
