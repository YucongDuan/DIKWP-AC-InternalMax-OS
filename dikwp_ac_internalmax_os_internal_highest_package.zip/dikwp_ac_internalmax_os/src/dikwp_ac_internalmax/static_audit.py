from __future__ import annotations

from pathlib import Path
from typing import Dict, List

FORBIDDEN = [
    "import socket", "from socket", "import requests", "import urllib", "subprocess", "os.system",
    "eval(", "exec(", "selenium", "playwright", "paramiko", "ftplib", "telnetlib",
    "shutil.rmtree", "disable_audit", "hide_logs", "persistence", "self_replication"
]


def audit_path(path: str | Path) -> Dict[str, object]:
    base = Path(path)
    findings: List[Dict[str, object]] = []
    for p in base.rglob("*.py"):
        if p.name == "static_audit.py":
            continue
        text = p.read_text(encoding="utf-8", errors="ignore")
        for term in FORBIDDEN:
            if term in text:
                findings.append({"file": str(p), "term": term})
    return {
        "pass": len(findings) == 0,
        "finding_count": len(findings),
        "findings": findings,
        "policy": "No network imports, subprocess, dynamic execution, hidden telemetry, host mutation, real-world actuation, or autonomous persistence helpers in the offline core."
    }
