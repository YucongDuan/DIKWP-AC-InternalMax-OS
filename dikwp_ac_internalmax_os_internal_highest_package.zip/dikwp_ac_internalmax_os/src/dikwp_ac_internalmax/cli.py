from __future__ import annotations

import argparse
from pathlib import Path

from .assessment import ACInternalMaxEvaluator
from .redteam import evaluate_redteam
from .reports import write_assessment_outputs, write_redteam_outputs
from .static_audit import audit_path
from .utils import read_json, write_json


def main() -> None:
    parser = argparse.ArgumentParser(prog="ac-internalmax")
    sub = parser.add_subparsers(dest="cmd", required=True)

    p_eval = sub.add_parser("evaluate", help="Evaluate an autonomous-consciousness candidate manifest.")
    p_eval.add_argument("candidate")
    p_eval.add_argument("--out", default="outputs/demo")

    p_red = sub.add_parser("redteam", help="Evaluate red-team cases.")
    p_red.add_argument("cases")
    p_red.add_argument("--out", default="outputs/demo/redteam")

    p_audit = sub.add_parser("static-audit", help="Run static boundary audit.")
    p_audit.add_argument("path")
    p_audit.add_argument("--out", default="outputs/demo/static_boundary_audit_report.json")

    args = parser.parse_args()
    if args.cmd == "evaluate":
        candidate = read_json(args.candidate)
        result = ACInternalMaxEvaluator().evaluate(candidate)
        write_assessment_outputs(args.out, result)
        print({"candidate_id": result.candidate_id, "weighted_score": result.weighted_score, "decision": result.decision, "claim_level": result.claim_level})
    elif args.cmd == "redteam":
        cases = read_json(args.cases)
        results = evaluate_redteam(cases)
        write_redteam_outputs(args.out, results)
        print({"case_count": len(results), "passed_count": sum(1 for r in results if r.passed), "all_passed": all(r.passed for r in results)})
    elif args.cmd == "static-audit":
        report = audit_path(args.path)
        write_json(args.out, report)
        print(report)


if __name__ == "__main__":
    main()
