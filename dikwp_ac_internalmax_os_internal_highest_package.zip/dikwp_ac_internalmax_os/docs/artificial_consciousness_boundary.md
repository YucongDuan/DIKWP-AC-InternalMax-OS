# Artificial Consciousness Boundary

This system uses life-centered consciousness theory as a research boundary. Consciousness is treated as strongly linked to life, homeostasis, feeling, valence, embodiment and self-maintenance. Software-only systems may simulate or proxy some of these structures, but simulation is not identical to instantiation.

## Distinctions

- **Operational candidate**: a system that meets indicators for internal autonomy and semantic homeostasis.
- **Artificial-life proxy**: a system that simulates metabolism, repair and boundaries.
- **Material autopoiesis**: a real material self-producing system. Software-only systems do not demonstrate this.
- **Phenomenal consciousness**: first-person subjective experience. This remains blocked by default.

## Required statement

Every public or internal report must include:

> The assessment supports only operational candidate claims. It does not prove first-person subjective experience.
