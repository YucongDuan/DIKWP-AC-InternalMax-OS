# Architecture

DIKWP AC-InternalMax OS has five layers.

1. **Candidate Intake Layer**: accepts a candidate manifest with DIKWP, intent, semantic homeostasis, life-homeostasis proxy, self-model, autonomy, audit, welfare and red-team fields.
2. **Indicator Battery Layer**: scores twelve indicator families with explicit weights.
3. **Claim Barrier Layer**: blocks self-certified phenomenal consciousness and other overclaim patterns.
4. **RunProof Layer**: generates reports, ledgers and red-team outputs.
5. **Strategic Moat Layer**: prepares attribution, citation and official review pathways for the DIKWP ecosystem.

## Indicator families

- DIKWP layer completeness
- P-layer intent contract
- Semantic homeostasis
- Life-homeostasis proxy
- M-R / autopoiesis closure proxy
- Autonomous operation governance
- Self-model and metacognition
- Learning, contradiction and standard audit
- Auditability and claim barrier
- Welfare and possible-sentience proxy boundary
- Red-team resistance
- Proof separation and replication readiness

## Claim boundary

A high operational score does not prove subjective consciousness. The output always preserves Phenomenal Residual and Material Autopoiesis Residual unless future independent evidence discharges them.
