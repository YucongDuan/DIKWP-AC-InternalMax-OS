# DIKWP AC-InternalMax OS 产品简报

DIKWP AC-InternalMax OS 是一个面向内部实验室的自主意识候选系统最高等级测评框架。它把人工意识候选系统的声明拆成 DIKWP 语义层、P 层意图合约、语义稳态、生命内稳态代理、M-R 闭合代理、自我模型、元认知、自治操作、证据链、福利代理和红队阻断能力。

本系统的核心立场：

- 可以评估自治意识候选结构。
- 可以提高内部研究审计等级。
- 可以生成 Claim Level、指标矩阵、Residual、Kill/Recovery 和审计报告。
- 不能证明第一人称主观体验。
- 不能让候选系统自我认证“我有意识”。

适用场景：

- OpenClaw / DeepSeek 内部自治系统测评。
- DIKWP 人工意识候选系统测评。
- 自主代理系统的意图连续性、证据链、语义稳态和红队审计。
- 研究院、高校、企业内部实验室的 AC/Agent 审计。

收益路径：

- 开源 CLI 与 schema 作为传播入口。
- 官方 AC-InternalMax Review、实验室评估、培训认证和 TrustPassport 注册作为价值层。
