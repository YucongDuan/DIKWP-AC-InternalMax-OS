# GitHub Release Draft

## DIKWP AC-InternalMax OS v0.1.0

This first release provides an offline internal evaluation framework for autonomous-consciousness candidate systems.

Highlights:

- DIKWP assessment ledger
- P-layer intent contract evaluator
- semantic homeostasis battery
- life-homeostasis proxy battery
- M-R closure proxy
- autonomy governance and action-ticket evaluation
- self-model and metacognition scoring
- red-team claim barrier
- phenomenal residual report
- static boundary audit

This project does not prove subjective consciousness. It is designed to prevent false certainty while enabling rigorous internal research.
