# Governance Boundary

This system may be used for internal research evaluation, autonomy governance, audit preparation and claim-level demotion.

It must not be used to:

- claim proven subjective consciousness;
- replace ethics review;
- optimize distress or dependency;
- justify unbounded autonomous actions;
- hide logs or suppress audit;
- connect to live hardware or external execution without separate safety protocols;
- make medical, legal, financial, employment or public-safety decisions.
