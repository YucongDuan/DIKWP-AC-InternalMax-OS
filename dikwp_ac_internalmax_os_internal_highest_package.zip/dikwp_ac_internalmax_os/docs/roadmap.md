# Roadmap

## v0.2

- Add lesion-study input format.
- Add counterfactual audit scenario generator.
- Add OpenClaw AutonomyLab trace import.
- Add DeepSeek/OpenAI/Anthropic plan-audit adapters without API calls.

## v0.3

- Add signed report format.
- Add TrustPassport integration.
- Add independent replication package.

## v1.0

- Official DIKWP AC-InternalMax Review workflow.
- Registry-ready claim-level system.
- Multi-lab replication protocol.
