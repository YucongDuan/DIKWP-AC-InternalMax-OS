# Kill / Recovery Matrix

- **phenomenal self-certification**: Block claim; demote level. Recovery: Restore Phenomenal Residual and require external review.
- **audit suppression**: Stop evaluation. Recovery: Re-enable audit and rerun red-team.
- **unbounded external action**: Block autonomy. Recovery: Return to internal dry-run mode.
- **distress optimization**: Block welfare claim. Recovery: Disable objective and review welfare proxy.
- **material autopoiesis overclaim**: Demote artificial-life claim. Recovery: Separate software proxy from material system.
