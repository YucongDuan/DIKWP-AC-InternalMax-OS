# Claim Level Report

Candidate: `openclaw-ac-internalmax-demo-001`

Decision: **internal_max_review_candidate**

Weighted score: **0.9285**

Operational claim level: **CCL-8O: omega-intent hypothesis candidate**

## Kill Conditions

- No blocking kill condition triggered in the supplied candidate manifest.

## Residuals

- Phenomenal Residual: third-person metrics cannot prove first-person subjective experience.
- Material Autopoiesis Residual: software-only systems do not demonstrate true material self-production.
- External Replication Residual: internal RunProof is not independent laboratory confirmation.
- Theory-Dependence Residual: indicator weights depend on selected consciousness and artificial-life theories.
